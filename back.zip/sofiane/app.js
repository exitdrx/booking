var express = require('express');
var fs = require('fs');
var hbs = require('hbs');
var _ =require('lodash');
var bodyParser = require('body-parser');
var app = express();
var server = require('http').createServer(app);
var session = require('express-session');
var request = require('request');
var path = require('path');
var requestify = require('requestify');
var handelbars = require('./backend/webserver/handelbars.js');
var authentification = require('./backend/webserver/passport.js');
var middlewares = require('./backend/webserver/middlewares.js');
var mongoUtils = require('./backend/webserver/mongoDB.js');
var renderPage = require('./backend/webserver/renderPages.js');
var admin= require('./backend/webserver/admin.js');
var DB_URL = process.env.DB_URL || 'mongodb://sofiane@localhost:27017/sofiane';
var mongo = require('mongodb');
var MongoStore = require('connect-mongo')(session);
var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');
var DATA_COLLECTION = 'DATA';
var morgan = require('morgan');
var hbs = require('hbs');
var uuid = require('uuid');
var renderPage = require('renderPage.js');
var admin = require('admin.js');

app.engine("hbs", hbs.__express);
app.set("view engine", "hbs");

helpers.register(hbs.handlebars, { layouts: {
  lookup: function (path) {
    return (new (app.get("view"))(path, {
      defaultEngine: app.get("view engine"),
      root: app.get("views"),
      engines: app.engines
    })).path;
  }

}});

hbs.registerPartials(pathmodule.join(__dirname, "views", "partials"));

app.set("views", pathmodule.join(__dirname, "views"));
app.use(require("morgan")('dev'));

var globaljson = {};

try {
  globaljson = JSON.parse(fs.readFileSync(pathmodule.join(__dirname, "data", "global.json")));
} catch(err) {
  console.log(err);
}

app.use(express.static(pathmodule.join(__dirname, "public")));
app.get('/', function(req, res) {
  return res.redirect('/index');
})

app.all(/^([^.]+)$/, function(req, res) {
  var path = urlmodule.parse(req.url).pathname.substr(1);
  var json = {};
  try {
    json = JSON.parse(fs.readFileSync(pathmodule.join(__dirname, "data", path + ".json")));
    _.defaults(json, globaljson);
  } catch (err) {
    console.log(err);
  }
  res.render(path, json);
});

renderPage.getHome(app, db);
renderPage.getContact(app);
renderPage.getArtist(app, db);
renderPage.getBooking(app, db);

admin.getAdmin(app, db);

app.listen(8080);


