var assert = require('assert');
var async = require('async');
var adminList=["benjamin.poilve@gmail.com","liazidiiamine@gmail.com","marine.fridman@gmail.com","ayoub.benseghir@gmail.com","h.djennaoui@gmail.com"];
function getAdmin(app, db){
    app.get('/admin/', isAdmin,  function(req, res, next) {
        var cursor = db.collection('ARTICLE').find();
        if(cursor != null){
            cursor.toArray(function(err, doc) {
                if (err) return next(err);
                else{
                    var array = [];
                    for(var i in doc){
                        var x = {
                            _id : doc[i]._id,
                            name : doc[i].name,
                            img : doc[i].img
                        };
                        array.push(x);
                    }
                    return res.render('admin', {
                        article : array || false
                    });
                }
            });
        }else{
            return res.render('admin', {
                article : false
            });
        }
    })
}
exports.getAdmin = getAdmin;

function isAdmin(req, res, next) {
    if(req.user){
     console.log(req.user.Mail);}
    if ((req.user) && (adminList.indexOf(req.user.Mail)>-1))
        return next();
    else
        return  res.status(404).send();;
}
exports.isAdmin = isAdmin;
