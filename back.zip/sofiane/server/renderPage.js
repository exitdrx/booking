 var middlewares= require('./middlewares.js');
 var mongoUtils = require('./mongoDB.js');
 var uuid = require('uuid');

 function renderHome(app, assert, db){
    app.get('/', function (req, res, next) {
        if(req.session.acceptedCookie!=true){
            req.session.acceptedCookie=false;
        }
        var cursor = db.collection('ARTICLE').find();
        if(cursor != null){
            cursor.toArray(function(err, doc) {
                if (err) return next(err);
                else{
                    doc = doc.filter(function(v) {
                        return v.post === "true";
                    })
                    return res.render('index', {
                        presentationData : doc
                    });
                }
            });
        }else{
            return res.render('error');
        }
    });

    app.get('/index', function (req, res) {
        return res.redirect('/');
    });
}
exports.renderHome = renderHome;

function getError(app){
    app.get('/error', function(req, res){
        return res.render('error',{
            url : false,
            error : false
        });
    });
}
exports.getError = getError;

