jQuery(function() {	
	// Date Picker
	jQuery("#datepicker").datepicker({dateFormat: 'm/d/yy'});
});